#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm install
# The android folder is already part of the project: only add it if it is missing.
if [ ! -d android ]; then
  npx cap add android
fi
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug
if [ -n "${UPLOAD_KEYSTORE_B64:-}" ]; then
  echo "$UPLOAD_KEYSTORE_B64" | base64 -d > "${RUNNER_TEMP:-/tmp}/upload.jks"
  export UPLOAD_STORE_FILE="${RUNNER_TEMP:-/tmp}/upload.jks"
  # Also needs UPLOAD_STORE_PASSWORD, UPLOAD_KEY_ALIAS (and optionally UPLOAD_KEY_PASSWORD) as secrets
  ./gradlew bundleRelease
else
  echo "No upload key secret found: skipping the release bundle"
fi
