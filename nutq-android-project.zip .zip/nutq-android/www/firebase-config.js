// الصق هون إعدادات مشروع Firebase (Project settings → Your apps → Web app)
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  appId: "PASTE_YOUR_APP_ID"
};
