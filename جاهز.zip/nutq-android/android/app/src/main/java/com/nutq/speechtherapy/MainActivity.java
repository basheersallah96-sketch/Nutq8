package com.nutq.speechtherapy;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
