// إعدادات تطبيق الويب (Web app) من مشروع Firebase: nutq-app-e89f2
// هاي القيم مش سرّية، والحماية الفعلية من قواعد Firestore.
export const firebaseConfig = {
  apiKey: "AIzaSyDIshYYqk6UvLYagLpgQo8q-1foYQIv9ps",
  authDomain: "nutq-app-e89f2.firebaseapp.com",
  projectId: "nutq-app-e89f2",
  storageBucket: "nutq-app-e89f2.firebasestorage.app",
  messagingSenderId: "602709913838",
  appId: "1:602709913838:web:21b4143ea3b10d923783ff"
};
