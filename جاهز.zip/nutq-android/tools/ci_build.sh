#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm install
npx cap add android
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug
if [ -n "${UPLOAD_KEYSTORE_B64:-}" ]; then
  echo "$UPLOAD_KEYSTORE_B64" | base64 -d > "${RUNNER_TEMP:-/tmp}/upload.jks"
  export UPLOAD_STORE_FILE="${RUNNER_TEMP:-/tmp}/upload.jks"
  ./gradlew bundleRelease
else
  echo "No upload key secret found: skipping the release bundle"
fi
