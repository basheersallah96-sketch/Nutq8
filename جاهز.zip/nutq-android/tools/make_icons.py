"""Applies assets/logo.png as Android launcher icon + launch splash.
Runs automatically after `cap sync` (see capacitor:sync:after in package.json)."""
import os, sys, glob, subprocess

try:
    from PIL import Image
except ImportError:
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--quiet',
                           '--break-system-packages', 'pillow'])
    from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'android', 'app', 'src', 'main', 'res')
LOGO = Image.open(os.path.join(ROOT, 'assets', 'logo.png')).convert('RGBA')

if not os.path.isdir(RES):
    print('android/res not found, skipping')
    sys.exit(0)

LEGACY = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
FOREGROUND = {'mdpi': 108, 'hdpi': 162, 'xhdpi': 216, 'xxhdpi': 324, 'xxxhdpi': 432}


def resized(size):
    return LOGO.resize((size, size), Image.LANCZOS)


def on_canvas(size, scale, bg=None):
    c = Image.new('RGBA', (size, size), bg or (0, 0, 0, 0))
    s = int(size * scale)
    c.alpha_composite(resized(s), ((size - s) // 2, (size - s) // 2))
    return c


for d in LEGACY:
    folder = os.path.join(RES, 'mipmap-' + d)
    os.makedirs(folder, exist_ok=True)
    resized(LEGACY[d]).save(os.path.join(folder, 'ic_launcher.png'))
    resized(LEGACY[d]).save(os.path.join(folder, 'ic_launcher_round.png'))
    on_canvas(FOREGROUND[d], 0.68).save(os.path.join(folder, 'ic_launcher_foreground.png'))

ADAPTIVE = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@android:color/white"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
'''
v26 = os.path.join(RES, 'mipmap-anydpi-v26')
os.makedirs(v26, exist_ok=True)
for n in ('ic_launcher.xml', 'ic_launcher_round.xml'):
    open(os.path.join(v26, n), 'w').write(ADAPTIVE)

# launch splash: replace every splash.png the template created
count = 0
for p in glob.glob(os.path.join(RES, '**', 'splash.png'), recursive=True):
    w, h = Image.open(p).size
    c = Image.new('RGBA', (w, h), (255, 255, 255, 255))
    s = int(min(w, h) * 0.45)
    c.alpha_composite(resized(s), ((w - s) // 2, (h - s) // 2))
    c.convert('RGB').save(p)
    count += 1
print('icons done, splash files replaced:', count)

# release configuration: SDK 36, version, upload-key signing (read from environment)
try:
    import re
    run = int(os.environ.get('GITHUB_RUN_NUMBER') or 1)
    VN = 'Basheer Abu Afia © 2026 - All rights reserved'
    vg = os.path.join(ROOT, 'android', 'variables.gradle')
    if os.path.isfile(vg):
        t = open(vg, encoding='utf-8').read()
        t = re.sub(r'(compileSdkVersion|targetSdkVersion)(\s*=\s*)\d+', r'\g<1>\g<2>36', t)
        open(vg, 'w', encoding='utf-8').write(t)
        print('variables.gradle: SDK 36 ensured')
    g = os.path.join(ROOT, 'android', 'app', 'build.gradle')
    if os.path.isfile(g):
        t = open(g, encoding='utf-8').read()
        t = re.sub(r'versionCode\s*=?\s*\d+', 'versionCode = %d' % run, t, count=1)
        t = re.sub(r'versionName\s*=?\s*"[^"]*"', 'versionName = "%s"' % VN, t, count=1)
        if 'UPLOAD_STORE_FILE' not in t:
            sc = """    signingConfigs {
        release {
            if (System.getenv('UPLOAD_STORE_FILE')) {
                storeFile = file(System.getenv('UPLOAD_STORE_FILE'))
                storePassword = System.getenv('UPLOAD_STORE_PASSWORD')
                keyAlias = System.getenv('UPLOAD_KEY_ALIAS')
                keyPassword = System.getenv('UPLOAD_KEY_PASSWORD')
            }
        }
    }
"""
            t = re.sub(r'(\n\s*)buildTypes\s*\{', lambda mm: '\n' + sc + mm.group(1) + 'buildTypes {', t, count=1)
            t = re.sub(r'(buildTypes\s*\{\s*release\s*\{)', r"\1\n            if (System.getenv('UPLOAD_STORE_FILE')) { signingConfig = signingConfigs.release }", t, count=1)
        open(g, 'w', encoding='utf-8').write(t)
        print('build.gradle: versionCode', run, '+ signing patched')
except Exception as e:
    print('release config skipped:', e)

# fixed debug keystore => constant SHA-1 (needed for Google sign-in), and Firebase config
try:
    import shutil
    ks = os.path.join(ROOT, 'tools', 'debug.keystore')
    if os.path.isfile(ks):
        d = os.path.join(os.environ.get('ANDROID_USER_HOME') or os.path.expanduser('~/.android'))
        os.makedirs(d, exist_ok=True)
        shutil.copyfile(ks, os.path.join(d, 'debug.keystore'))
        print('fixed debug keystore installed')
    gs = os.path.join(ROOT, 'google-services.json')
    if os.path.isfile(gs):
        shutil.copyfile(gs, os.path.join(ROOT, 'android', 'app', 'google-services.json'))
        print('google-services.json copied')
    else:
        print('no google-services.json found')
except Exception as e:
    print('keystore/firebase step skipped:', e)
